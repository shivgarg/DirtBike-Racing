<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="x-dns-prefetch-control" content="off">

<title>Computer Services Centre</title><script language="JavaScript" type="text/javascript">
<!--
function checkForm() {
   var f = document.forms.length;
   var i = 0;
   var pos = -1;
   while( pos == -1 && i < f ) {
       var e = document.forms[i].elements.length;
       var j = 0;
       while( pos == -1 && j < e ) {
           if ( document.forms[i].elements[j].type == 'text'            || document.forms[i].elements[j].type == 'password' ) {
               pos = j;
           }
           j++;
       }
   i++;
   }
   if( pos >= 0 ) {
       document.forms[i-1].elements[pos].focus();
   }
   
}
// -->
</script>

<!--[if IE 6]>
<style type="text/css">
/* avoid stupid IE6 bug with frames and scrollbars */
body {
    width: expression(document.documentElement.clientWidth - 30);
}
</style>
<![endif]-->

</head>

<body text="#000000" bgcolor="#ffffff" link="#0000cc" vlink="#0000cc" alink="#0000cc" onload="checkForm();">

<a name="pagetop"></a>
<table bgcolor="#ffffff" border="0" width="100%" cellspacing="0" cellpadding="2">

<tr bgcolor="#ababab">

<td align="left">

&nbsp;      </td>
<td align="right">
<b>
<a href="/src/signout.php" target="_top">Sign Out</a></b></td>
   </tr>
<tr bgcolor="#ffffff">

<td align="left">

<a href="/src/compose.php?mailbox=None&amp;startMessage=0">Compose</a>&nbsp;&nbsp;
<a href="/src/addressbook.php">Addresses</a>&nbsp;&nbsp;
<a href="/src/folders.php">Folders</a>&nbsp;&nbsp;
<a href="/src/options.php">Options</a>&nbsp;&nbsp;
<a href="/src/search.php?mailbox=None">Search</a>&nbsp;&nbsp;
<a href="/src/help.php">Help</a>&nbsp;&nbsp;
      </td>
<td align="right">

<a href="http://www.iitd.ernet.in" target="_blank"><IMG SRC="https://webmail.iitd.ernet.in/images/iitlogo.gif" WIDTH="180" ALT="IITD Logo" BORDER="0"></a></td>
   </tr>
</table><br>

<br /><table width="100%" border="0" cellspacing="0" cellpadding="2" align="center"><tr><td bgcolor="#dcdcdc">
<b><center>
Viewing a text attachment - <a href="read_body.php?mailbox=INBOX&amp;passed_id=1329&amp;startMessage=1&amp;ent_id=0">View message</a></b></td><tr><tr><td><center>
<a href="../src/download.php?mailbox=INBOX&amp;passed_id=1329&amp;startMessage=1&amp;ent_id=2&amp;absolute_dl=true">Download this as a file</a></center><br />
</center></b>
</td></tr></table>
<table width="98%" border="0" cellspacing="0" cellpadding="2" align="center"><tr><td bgcolor="#dcdcdc">
<tr><td bgcolor="#ffffff"><tt>
<pre># Blender MTL File: 'None'
# Material Count: 7

newmtl material_0
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.000000 0.000000 0.000000
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2

newmtl material_1
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.800000 0.075294 0.000000
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2

newmtl material_2
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.480000 0.480000 0.480000
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2

newmtl material_3
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.800000 0.800000 0.800000
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2

newmtl material_4
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.320000 0.480000 0.640000
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2

newmtl material_5
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.235294 0.075294 0.075294
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2

newmtl material_6
Ns 0.000000
Ka 0.000000 0.000000 0.000000
Kd 0.075294 0.075294 0.235294
Ks 1.000000 1.000000 1.000000
Ni 1.000000
d 1.000000
illum 2
</pre></tt></td></tr></table>
</body></html>
