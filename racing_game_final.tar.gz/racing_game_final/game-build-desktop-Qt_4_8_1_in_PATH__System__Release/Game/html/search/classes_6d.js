var searchData=
[
  ['manager',['Manager',['../classManager.html',1,'']]]
];
