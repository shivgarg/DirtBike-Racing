var searchData=
[
  ['next',['next',['../classManager.html#a8e930a4151fb3f999f31c0498f2bbdde',1,'Manager']]]
];
