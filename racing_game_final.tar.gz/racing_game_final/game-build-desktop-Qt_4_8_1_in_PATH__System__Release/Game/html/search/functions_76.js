var searchData=
[
  ['vector3d',['Vector3D',['../classVector3D.html#a0b11a8d75da427b27443d8a94d0d296c',1,'Vector3D::Vector3D()'],['../classVector3D.html#a7b0f18fa43c7a90588dedcd814122359',1,'Vector3D::Vector3D(float a, float b, float c)'],['../classVector3D.html#a765ee7fc4bf9c338cb96fbd0499257a1',1,'Vector3D::Vector3D(const Vector3D &amp;v)']]]
];
