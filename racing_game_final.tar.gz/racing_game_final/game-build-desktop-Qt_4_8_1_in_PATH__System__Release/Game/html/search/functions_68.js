var searchData=
[
  ['handlecollision',['HandleCollision',['../classManager.html#a6a1af4cca4eeebc54975b5d5b6a92243',1,'Manager']]]
];
