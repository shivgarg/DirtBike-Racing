var searchData=
[
  ['init',['init',['../classObject.html#a27e1e8844b2e46ae4992ff6e28a7ac47',1,'Object']]]
];
