var searchData=
[
  ['bonus',['bonus',['../structbonus.html',1,'']]]
];
