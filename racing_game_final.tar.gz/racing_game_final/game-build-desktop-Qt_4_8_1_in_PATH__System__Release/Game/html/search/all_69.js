var searchData=
[
  ['ids',['ids',['../classterrain.html#abab37c6ed21ad3de44b7b11f31b702e6',1,'terrain']]],
  ['init',['init',['../classObject.html#a27e1e8844b2e46ae4992ff6e28a7ac47',1,'Object']]]
];
