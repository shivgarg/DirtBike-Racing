var searchData=
[
  ['unit',['unit',['../classVector3D.html#a488df8e5795747d30f90c7f0d53ea27c',1,'Vector3D::unit(Vector3D v)'],['../classVector3D.html#ace41d61f9b58615ac6e9bdcb8656934e',1,'Vector3D::unit()']]],
  ['updatevel',['UpdateVel',['../classManager.html#a4f6f189d7e017b645fdd6c59329e7249',1,'Manager']]]
];
