var searchData=
[
  ['project',['project',['../classVector3D.html#a8acd75715a111793766937ce2d7cb3a6',1,'Vector3D::project(Vector3D w)'],['../classVector3D.html#a338a0b282e010b789e59f141eb26e55a',1,'Vector3D::project(Vector3D v, Vector3D w)']]]
];
