var searchData=
[
  ['coordxy',['coordxy',['../structcoordxy.html',1,'']]]
];
