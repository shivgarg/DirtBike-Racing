var searchData=
[
  ['data',['data',['../classTexture.html#ad0dc96bb867719f5bdaf02197c6bddbe',1,'Texture::data()'],['../classterrain.html#ad07206f55359d1f2084ece2b06675425',1,'terrain::data()']]]
];
